# Budget App

Application web de gestion financière.

## Utilisation
Ouvrez `index.html` dans votre navigateur.
